package com.noir.launcher

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private val black = Color.BLACK
    private val white = Color.WHITE
    private val muted = Color.rgb(135, 135, 135)
    private lateinit var root: FrameLayout
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var drawerOpen = false
    private var downY = 0f
    private val tick = object : Runnable {
        override fun run() {
            if (::clock.isInitialized) {
                clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                date.text = SimpleDateFormat("EEEE  /  dd.MM.yyyy", Locale.getDefault()).format(Date()).uppercase(Locale.getDefault())
            }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = black
        window.navigationBarColor = black
        window.decorView.systemUiVisibility = 0
        showHome()
        handler.post(tick)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    private fun baseRoot(): FrameLayout {
        return FrameLayout(this).apply {
            setBackgroundColor(black)
            setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { downY = event.y; true }
                    MotionEvent.ACTION_UP -> {
                        val delta = event.y - downY
                        if (!drawerOpen && delta < -75) showDrawer()
                        else if (drawerOpen && delta > 75) showHome()
                        true
                    }
                    else -> true
                }
            }
        }
    }

    private fun showHome() {
        drawerOpen = false
        root = baseRoot()
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(26), dp(30), dp(26), dp(22))
        }
        val top = horizontal()
        top.addView(label("NØ  /  SYSTEM", 12, white, true), weightParams())
        top.addView(label("ONLINE  •  01", 10, muted, true), wrapParams())
        page.addView(top)
        page.addView(space(72))

        clock = label("00:00", 76, white, false).apply { typeface = Typeface.create("sans-serif-light", Typeface.NORMAL); letterSpacing = -0.055f }
        page.addView(clock)
        date = label("LOADING DATE", 11, muted, true).apply { letterSpacing = 0.12f }
        page.addView(date)
        page.addView(space(44))
        page.addView(rule())
        page.addView(space(18))
        page.addView(label("QUICK ACCESS  /  04", 10, muted, true).apply { letterSpacing = 0.16f })
        page.addView(space(16))

        val apps = launchableApps().take(4)
        val grid = GridLayout(this).apply { columnCount = 4; useDefaultMargins = false }
        apps.forEach { app -> grid.addView(appTile(app), GridLayout.LayoutParams().apply { width = 0; height = dp(94); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f) }) }
        if (apps.isEmpty()) page.addView(label("NO APPS FOUND", 12, muted, false)) else page.addView(grid)
        page.addView(space(28))
        page.addView(rule())
        page.addView(space(18))
        page.addView(label("SYSTEM STATUS", 10, muted, true).apply { letterSpacing = 0.16f })
        page.addView(space(12))
        page.addView(statusRow("INTERFACE", "NØ LAUNCHER  /  0.1"))
        page.addView(statusRow("DEVICE", "ONEPLUS NORD 3"))
        page.addView(statusRow("MODE", "MONOCHROME"))
        val spacer = View(this)
        page.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))
        page.addView(label("SWIPE UP  /  ALL APPLICATIONS", 10, muted, true).apply { gravity = Gravity.CENTER; letterSpacing = 0.12f })
        page.addView(space(16))
        page.addView(label("NØ     ━━━━━━━━━━━━━━━━━     001", 9, muted, true).apply { gravity = Gravity.CENTER })

        root.addView(page, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        tick.run()
    }

    private fun showDrawer() {
        drawerOpen = true
        root = baseRoot()
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(24), dp(22), dp(12)) }
        val header = horizontal()
        header.addView(label("APPLICATIONS", 19, white, true), weightParams())
        header.addView(label("NØ / 02", 10, muted, true), wrapParams())
        page.addView(header)
        page.addView(space(18))
        val search = EditText(this).apply {
            hint = "SEARCH APPLICATIONS"
            setHintTextColor(muted); setTextColor(white); textSize = 12f
            singleLine = true; setBackgroundColor(Color.rgb(18,18,18)); setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        page.addView(search, LinearLayout.LayoutParams(-1, dp(48)))
        page.addView(space(12))
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val allApps = launchableApps()
        fun populate(query: String) {
            list.removeAllViews()
            allApps.filter { it.label.toString().contains(query, true) }.forEach { app ->
                val row = horizontal().apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(10), dp(4), dp(10)) }
                val icon = ImageView(this).apply { setImageDrawable(app.loadIcon(packageManager)); grayscale(this); scaleType = ImageView.ScaleType.FIT_CENTER }
                row.addView(icon, LinearLayout.LayoutParams(dp(34), dp(34)))
                val name = label(app.label.toString().uppercase(Locale.getDefault()), 12, white, true)
                name.setPadding(dp(16), 0, 0, 0)
                row.addView(name, weightParams())
                row.addView(label("OPEN  ↗", 9, muted, true), wrapParams())
                row.setOnClickListener { launch(app.packageName) }
                list.addView(row)
                list.addView(rule())
            }
        }
        populate("")
        search.addTextChangedListener(SimpleWatcher { populate(it) })
        page.addView(label("SWIPE DOWN  /  HOME", 10, muted, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(8)) })
        root.addView(page, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        search.requestFocus()
    }

    private fun launchableApps(): List<ApplicationInfo> {
        return packageManager.getInstalledApplications(0)
            .filter { packageManager.getLaunchIntentForPackage(it.packageName) != null && it.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }
    }

    private fun launch(pkg: String) {
        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
    }

    private fun appTile(app: ApplicationInfo): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(3), dp(4), dp(3), dp(4)) }
        val icon = ImageView(this).apply { setImageDrawable(app.loadIcon(packageManager)); grayscale(this); scaleType = ImageView.ScaleType.FIT_CENTER }
        box.addView(icon, LinearLayout.LayoutParams(dp(38), dp(38)))
        box.addView(label(app.loadLabel(packageManager).toString().uppercase(Locale.getDefault()).take(11), 9, white, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(9), 0, 0) })
        box.setOnClickListener { launch(app.packageName) }
        return box
    }

    private fun grayscale(view: ImageView) {
        val matrix = ColorMatrix().apply { setSaturation(0f) }
        view.colorFilter = ColorMatrixColorFilter(matrix)
    }

    private fun statusRow(left: String, right: String): View = horizontal().apply {
        addView(label(left, 10, muted, true), weightParams())
        addView(label(right, 10, white, true), wrapParams())
        setPadding(0, dp(8), 0, dp(8))
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color)
        typeface = if (bold) Typeface.create("sans-serif-medium", Typeface.NORMAL) else Typeface.create("sans-serif", Typeface.NORMAL)
        includeFontPadding = false
    }
    private fun horizontal() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun rule() = View(this).apply { setBackgroundColor(Color.rgb(48,48,48)); layoutParams = LinearLayout.LayoutParams(-1, dp(1)) }
    private fun weightParams() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
    private fun wrapParams() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}

private class SimpleWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString().orEmpty()) }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
